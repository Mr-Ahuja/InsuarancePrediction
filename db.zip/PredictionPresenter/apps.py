from django.apps import AppConfig


class PredictionpresenterConfig(AppConfig):
    name = 'PredictionPresenter'
